package usuarioclave;

public class Autenticacion {
    private String vUsuario;
    private String vClave;

    public String getvUsuario() {
        return vUsuario;
    }

    public void setvUsuario(String vUsuario) {
        if (vUsuario.length() < 5 || vUsuario.length() > 12) {
            System.out.println("Error");
        } else {
            this.vUsuario = vUsuario;            
        }
    }

    public String getvClave() {
        String salida = "";
        for (int i = 1; i <= vClave.length(); i++) {
            salida += "*";
        }
        return salida;
    }

    public void setvClave(String vClave) {
        if (vClave.length() < 8) {
            System.out.println("Error");
        } else {
            this.vClave = vClave;            
        }
    }
    
    public boolean Verificacion() {
        if (vUsuario.equals("profe") && vClave.equals("12345678")) {
        return true;
        } else {
        return false;
        }
       
    }
    
    
}
