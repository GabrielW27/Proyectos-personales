package usuarioclave;

import javax.swing.JOptionPane;

public class UsuarioClave {

    public static void main(String[] args) {
        Autenticacion aut = new Autenticacion();
        
        do {
            aut.setvUsuario(JOptionPane.showInputDialog("Ingrese su usuario"));
            aut.setvClave(JOptionPane.showInputDialog("Ingrese su clave"));
           
        } while (!aut.Verificacion());
        JOptionPane.showMessageDialog(null, "Acceso autorizado");
        
        
    }
    
}
