package hoteluh;

import javax.swing.JOptionPane;

public class Datos {
    // Definir un arreglo de objetos
    private Habitacion Habitaciones[][] = new Habitacion[10][6];
    
    // En el constructor lleno el arreglo con objetos Habitacion
    public Datos() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 6; j++) {
                Habitaciones[i][j] = new Habitacion();
            }
        }
    }
    
    public void Entrada() {
        int piso = Integer.parseInt(JOptionPane.showInputDialog("Piso")) -1;
        int cuarto = Integer.parseInt(JOptionPane.showInputDialog("Cuarto")) -1;
        int cantidadHuespedes = 0;
        if (Habitaciones[piso][cuarto].estado == 0){
            Habitaciones[piso][cuarto].nombreCliente = JOptionPane.showInputDialog("Cliente");
            Habitaciones[piso][cuarto].fechaIngreso = JOptionPane.showInputDialog("Ingreso");
            Habitaciones[piso][cuarto].fechaSalida = JOptionPane.showInputDialog("Salida");
            Habitaciones[piso][cuarto].totalCosto = Double.parseDouble(JOptionPane.showInputDialog("Costo"));
            Habitaciones[piso][cuarto].adelanto = Double.parseDouble(JOptionPane.showInputDialog("Adelanto"));
            cantidadHuespedes = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de huéspedes"));
            for (int huesped = 0; huesped < cantidadHuespedes; huesped++) {
                Habitaciones[piso][cuarto].huespedes[huesped] = JOptionPane.showInputDialog("Nombre huesped " + (huesped+1));
            }
            Habitaciones[piso][cuarto].estado = 1;
        } else {
            JOptionPane.showMessageDialog(null, "Esa habitación ya está ocupada");
        }
    }
    
    public void Salida() {
        int piso = Integer.parseInt(JOptionPane.showInputDialog("Piso")) -1;
        int cuarto = Integer.parseInt(JOptionPane.showInputDialog("Cuarto")) -1;
        if (Habitaciones[piso][cuarto].estado == 1) {
            JOptionPane.showMessageDialog(null, "Total a pagar: " + Habitaciones[piso][cuarto].Saldo());
            Habitaciones[piso][cuarto].estado = 0;
            //Habitaciones[piso][cuarto] = new Habitacion();
        } else {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    public void Reporte() {
        // Mostrar solamente cuales habitaciones están o no disponibles
    }
    
    public void Disponible() {
        // Buscar de manera ordenada la primera habitación disponible
        
    }
}
