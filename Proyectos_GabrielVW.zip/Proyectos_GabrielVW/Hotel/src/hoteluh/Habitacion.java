package hoteluh;

public class Habitacion {
     String nombreCliente;
     String fechaIngreso;
     String fechaSalida;
     double totalCosto;
     double adelanto;
     int estado = 0;
     String huespedes[] = new String[3];
    
    // Controlar no tengamos nombres de huespedes NULL
    public Habitacion() {
        for (int i = 0; i < 3; i++) {
            huespedes[i] = "";
        }
    }
    
    public double Saldo() {
        return totalCosto - adelanto;
    }
}
