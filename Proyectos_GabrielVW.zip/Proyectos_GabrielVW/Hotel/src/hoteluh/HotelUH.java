package hoteluh;

import javax.swing.JOptionPane;

public class HotelUH {

    public static void main(String[] args) {
        int opcion = 1;
        Datos datos = new Datos();
        
        while (opcion !=0) {
            opcion = Integer.parseInt(JOptionPane.showInputDialog("1. Entrada\n2. Salida\n3. Reporte\n4. Disponible\n0. Salir"));
            switch (opcion) {
                case 1 -> datos.Entrada();
                case 2 -> datos.Salida();
                case 3 -> datos.Reporte();
                case 4 -> datos.Disponible();
            }
        }
    }
    
}
